#include "http/WinHttpClient.h"
#include "c_utils.h"
#include "base64.h"


class c_api 
{
public:
    static bool c_login(string c_username, string c_password, string c_hwid = "meme");
	static wstring c_dll();
};