#include "c_api.h"
#include "split.h"
#pragma warning(disable:4996)

wstring c_api::api = L"http://localhost/api/";
string c_api::token = "";

bool c_api::c_login(string c_username, string c_password, string c_hwid) {
	if (c_hwid == "meme") c_hwid = c_utils::hardware_id();

	WinHttpClient client(api + L"c_handle.php" + L"?m=a&username=" + c_utils::string_to_wstring(c_username) + L"&password=" + c_utils::string_to_wstring(c_password) + L"&hwid=" + c_utils::string_to_wstring(c_hwid));
	client.SendHttpRequest();
	string result = base64_decode(base64_decode(c_utils::wstring_to_string(client.GetResponseContent())));

	if (result == "") 
	{
		MessageBox(0, L"empty_response", L"", MB_OK);
		return false;
	}
	else if (result == "empty_username")
	{
		MessageBox(0, L"empty_username", L"", MB_OK);
		return false;
	}
	else if (result == "invalid_username")
	{
		MessageBox(0, L"invalid_username", L"", MB_OK);
		return false;
	}
	else if (result == "empty_password")
	{
		MessageBox(0, L"empty_password", L"", MB_OK);
		return false;
	}
	else if (result == "wrong_password")
	{
		MessageBox(0, L"wrong_password", L"", MB_OK);
		return false;
	}
	else if (result == "no_sub")
	{
		MessageBox(0, L"no_sub", L"", MB_OK);
		return false;
	}
	else if (result == "wrong_hwid")
	{
		MessageBox(0, L"wrong_hwid", L"", MB_OK);
		return false;
	}
	else if(result.find("logged_in") != string::npos)
	{
		std::vector<string> x_x = x_spliter::split(result, '|');
		token = x_x[1];

		return true;
	}
	else {
		MessageBox(0, L"unknown_response", L"", MB_OK);
		return false;
	}
}
  
char* c_api::c_dll() {  //buggy as hell + i shouldnt define this as a wstring
	WinHttpClient client(api + L"c_download.php" + L"?t=" + c_utils::string_to_wstring(token));
	client.SendHttpRequest();

	if (client.GetResponseContent() != L"") {
		return (char*)client.GetResponseContent().c_str();
	}
	else {
		return (char*)"null_response";
	}
}