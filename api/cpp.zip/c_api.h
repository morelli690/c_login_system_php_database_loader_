#include "http/WinHttpClient.h"
#include "c_utils.h"
#include "base64.h"
#include "caesar.h"
#include "split.h"


class c_api 
{
public:
    static bool c_login(string c_username, string c_password, string c_hwid = "meme");
	static char* c_dll();
	static string token;
private:
	static wstring api;
};