
class c_utils {
public:
	static std::string wstring_to_string(const std::wstring& ws) {
		const std::string s(ws.begin(), ws.end());
		return s;
	}
	static std::wstring string_to_wstring(const std::string& s) {
		const std::wstring ws(s.begin(), s.end());
		return ws;
	}
	static std::string hardware_id() {
		HW_PROFILE_INFO hwProfileInfo;
		if (GetCurrentHwProfile(&hwProfileInfo)) {
			std::wstring ws(hwProfileInfo.szHwProfileGuid); //there are better ways ik
			std::string str(ws.begin(), ws.end());
			return str;
		}
	}
};